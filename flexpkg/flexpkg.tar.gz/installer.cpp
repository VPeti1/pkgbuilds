#include <cstdlib>
#include <iostream>
#define clear std::cout << "\033[2J\033[1;1H";
using namespace std;

int main() {
    clear;
    system("sudo touch /usr/flex/arch.cw");
    clear
    system("read -p 'Press Enter to continue...'");
    system("sudo rm -rf /usr/flex/");
    system("sudo mkdir /usr/flex");
    system("sudo git clone https://github.com/VPeti1/FlexPkg.git /usr/flex");
    system("sudo g++ /usr/flex/run.cpp -o /bin/flex");
    system("sudo chmod +x /bin/flex");
    system("sudo rm -r /usr/flex/chococ.cpp /usr/flex/chococ.exe /usr/flex/installer.cpp /usr/flex/installer.out /usr/flex/LICENSE /usr/flex/README.md /usr/flex/run.cpp /usr/flex/run.out /usr/flex/examples /usr/flex/wininstall");
}
