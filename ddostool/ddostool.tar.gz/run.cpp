#include <iostream>
#include <cstdlib>

int main() {
    system("python3 /usr/ddostool/main.py");
}