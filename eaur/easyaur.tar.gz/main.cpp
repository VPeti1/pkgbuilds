#include <iostream>
#include <string>
#include <algorithm>
#include <unistd.h>
#include <filesystem>
#include <cstdlib>
#include <fstream>
namespace fs = std::filesystem;
#define clear system("clear");
using namespace std;

std::string pkg;
std::string pkggit;
std::string directoryPath;
std::string currentDirectory = std::filesystem::current_path().string();


void detectsudo() {
    if (geteuid() == 0) {
    std::cout << "SUDO is not supported! Please rerun the program without SUDO" << std::endl;
    exit(1);
}
}

void fail() {
    clear
    std::cout << "Package dosn't exist on the AUR\n";
    std::filesystem::remove_all(directoryPath);
}

bool hasFiles(const std::string& path) {
    for (const auto& entry : fs::directory_iterator(path)) {
        if (entry.is_regular_file()) {
            // Found a file
            return true;
        }
    }
    // No files found
    return false;
}
int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <package_name>\n";
        exit(1);
    }
    clear
    std::string pkg = argv[1];
    std::transform(pkg.begin(), pkg.end(), pkg.begin(), ::tolower);

    if (pkg == "createrepo") {
    std::string home_dir = std::getenv("HOME");
    std::string file_path = home_dir + "/.ssh/aur.pub";
    std::ifstream file(file_path);
    if (file.is_open()) {
        std::cout << "AUR ssh key found." << std::endl;
        file.close();
    } else {
        std::cout << "No AUR ssh file found" << std::endl;
        exit(1);
    }
        const char* command = "makepkg --printsrcinfo > .SRCINFO";
        int excode = std::system(command);
        if (excode == !0) {
            std::cout << "Failed to read from PKGBUILD file!";
        }
        std::cout << "Whats the packages name?\n";
        std::string input;
        std::cin >> input;
        std::string pkggit = input + ".git";
    std::cout << "Checking if package '" << pkg << "' exists\n";
    const std::string directoryPath = currentDirectory + "/" + pkg;
    std::filesystem::remove_all(directoryPath);
    system(("git -c init.defaultbranch=master clone ssh://aur@aur.archlinux.org/ " + pkggit).c_str());
    if (hasFiles(directoryPath)) {
        clear
        std::cout << "Package alredy exists on the AUR\n";
        exit(1);
    }
    system(("cp PKGBUILD .SRCINFO /" + input).c_str());
    std::filesystem::current_path(directoryPath);
    system(("git -c init.defaultbranch=master clone ssh://aur@aur.archlinux.org/" + pkggit).c_str());
    system("git -c init.defaultBranch=master init");
    system(("git remote add label ssh://aur@aur.archlinux.org/" + pkggit).c_str());
    system("git add PKGBUILD .SRCINFO");
    string commitMessage;
    cout << "Enter your commit message: ";
    getline(cin, commitMessage);
    string gitCommand = "git commit -m \"" + commitMessage + "\"";
    system(gitCommand.c_str());
    system("git push");
    }
    else {
    std::string pkggit = "https://aur.archlinux.org/" + pkg + ".git";
    std::cout << "Checking if package '" << pkg << "' exists\n";
    const std::string directoryPath = currentDirectory + "/" + pkg;
    std::filesystem::remove_all(directoryPath);
    system(("git clone --recurse --quiet " + pkggit).c_str());
    if (hasFiles(directoryPath)) {
        clear
        std::cout << "Package has been found on the AUR\n";
        std::filesystem::current_path(directoryPath);
        const char* command = "makepkg -si";
        int excode = std::system(command);
        if (excode == 0) {
            std::cout << "Package installed successfully." << std::endl;
            sleep(1);
            std::filesystem::remove_all(directoryPath);
            exit(0);
        }
        else {
            std::cerr << "MAKEPKG command failed with exit code: " << excode << std::endl;
            sleep(1);
            std::filesystem::remove_all(directoryPath);
            exit(1);
        }
    } else {
        fail();
        exit(1);
    }
}
}
