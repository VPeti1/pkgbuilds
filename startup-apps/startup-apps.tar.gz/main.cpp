#include <iostream>
#include <cstdlib>
#include <string>
#include <thread>
#include <unistd.h>
#include <fstream>
#include <filesystem>

void sudocheck() {
    if (getuid()) {
        printf("%s", "Please rerun the program as root!\n");
        exit(1);
    } 
}

int main() {
    sudocheck();
    std::filesystem::path currentPath = std::filesystem::current_path();
    std::string desc, path, type, create, editor, name;
    std::cout << "What will be your startup app service name?\n";
    std::cin >> name;
    std::cout << "What will be your startup apps description?\n";
    std::cin >> desc;
    std::cout << "Do you want to execute a script or not?\n";
    std::cin >> type;
    if (type == "y" | type == "yes" | type == "Y" | type == "Yes") {
        std::cout << "Do you want to create the script now?\n";
        std::cin >> create;
        if (create == "y" | create == "yes" | create == "Y" | create == "Yes") {
            std::cout << "What editor do you want to use?\n";
            std::cin >> editor;
            std::filesystem::path filePath = currentPath / "script.sh";
            system((editor + " " + filePath.string()).c_str());
            std::cout << "Where do you want to save the script??\n";
            std::cin >> path;
            std::ifstream inputFile(filePath);
            std::ofstream outputFile(path);
            char ch;
            while (inputFile.get(ch)) {
            outputFile.put(ch);
            }
            inputFile.close();
            outputFile.close();
        }
        else {
            std::cout << "Whats the path of the script?\n";
            std::cin >> path;
        }
    }
    else {
        std::cout << "Whats the path of the executable?\n";
        std::cin >> path;
    }
    std::string username = getlogin();

    std::filesystem::path filePathservice = currentPath / "servicetemp.service";
    std::ofstream outputFile(filePathservice.string());

    if (outputFile.is_open()) {
        outputFile << "[Unit]" << std::endl;
        outputFile << "Description=" + desc << std::endl;
        outputFile << "After=network.target" << std::endl << std::endl;
        outputFile << "[Service]" << std::endl;
        outputFile << "ExecStart=" + path << std::endl;
        outputFile << "Restart=always" << std::endl;
        outputFile << "User=" + username << std::endl << std::endl;
        outputFile << "[Install]" << std::endl;
        outputFile << "WantedBy=default.target" << std::endl;
        outputFile.close();
        
    } else {
        std::cerr << "Error creating the file." << std::endl;
        exit(1);
    }
    std::cout << "Service contents:\n";
    std::ifstream inputFile("servicetemp.service");
    if (inputFile.is_open()) {
        std::string line;
        while (std::getline(inputFile, line)) {
            std::cout << line << std::endl;
        }
    inputFile.close();
    system("read -p 'Press enter to save changes'");
    std::string systemdpath =  "/etc/systemd/system/" + name + ".serice";
    std::ifstream inputFile(filePathservice);
    std::ofstream outputFile(systemdpath);
    char ch;
    while (inputFile.get(ch)) {
        outputFile.put(ch);
    }
    inputFile.close();
    outputFile.close();
    std::cout << "Finished\n";
}
}
