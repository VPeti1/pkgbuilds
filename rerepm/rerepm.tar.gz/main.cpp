#include <iostream>
#include <string>
#include <fstream>
#include <unistd.h>
#include <sys/stat.h>
#define clear std::cout << "\033[2J\033[1;1H";
using namespace std;

void arch();


string checkpm(string& name) {
    string path = "/usr/bin/" + name;
    struct stat buffer; 
    int result = (stat(path.c_str(), &buffer) == 0 ? 0 : 1);
    return std::to_string(result);
}

void welcome() {
    clear
    std::cout << "Welcome to the REREpm!" << std::endl;
    std::cout << "Avalible commands:'update','install','remove','exit' " << std::endl;
    std::cout << "Type 'flatpak' for managing flatpak" << std::endl;
    std::cout << "Type 'snap' for managing snap" << std::endl;
    std::cout << "Type 'pip' for managing pip" << std::endl;
    std::cout << "Type in 'aur' to download packages from the AUR" << std::endl;
    std::cout << "Type in 'mremove' to remove multiple packages" << std::endl;
    arch(); 
}
void aur() {
    string packageManager = "yay";
    string check = checkpm(packageManager);
    if (check == "1") {
        std::cout << "You dont have that package mananger installed";
        welcome();
    }
    std::cout << "What package do you want to download?";
    std::string input;
    std::cin >> input;
    system(("yay -S " + input).c_str());
}
    

void flatpak() {
    clear
    string packageManager = "flatpak";
    string check = checkpm(packageManager);
    if (check == "1") {
        std::cout << "You dont have that package mananger installed";
        welcome();
    }
    std::cout << "You are now managing flatpak" << std::endl;
    std::cout << "Avalible commands:'update','install','remove','exit' " << std::endl;
    //Idk whose gonna use this but is here 
    std::string input;
    std::cin >> input;
    if (input == "update" || input == "Update") {
        clear
        system("flatpak update");
        flatpak();
    }
    else if (input == "install" || input == "Install") {
            //this is defenetly not from OpenCW
            //developers never copy :)
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("flatpak install " + input).c_str());
            flatpak();
    }
    else if (input == "remove" || input == "Remove") {
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("flatpak remove " + input).c_str());
            flatpak();
    }

    else if (input == "exit" || input == "Exit") {
        clear
    }

    else{
        std::cout << "Invalid input! Retrying" << std::endl;
        system("read -p 'Press Enter to continue...'");
        welcome();
        flatpak();
    }


}

void pip() {
    clear
    string packageManager = "pip";
    string check = checkpm(packageManager);
    if (check == "1") {
        std::cout << "You dont have that package mananger installed";
        welcome();
    }
    std::cout << "You are now managing pip" << std::endl;
    std::cout << "Avalible commands:'install','remove','exit' " << std::endl;
    //Idk whose gonna use this but is here 
    std::string input;
    std::cin >> input;
    if (input == "install" || input == "Install") {
            //this is defenetly not from OpenCW
            //developers never copy :)
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            //It dosnt break packages it just bypasses pep668
            system(("pip install --break-system-packages " + input).c_str());
            pip();
    }
    else if (input == "remove" || input == "Remove") {
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("pip uninstall --break-system-packages " + input).c_str());
            pip();
    }

    else if (input == "exit" || input == "Exit") {
        clear
    }

    else{
        std::cout << "Invalid input! Retrying" << std::endl;
        system("read -p 'Press Enter to continue...'");
        pip();
    }


}

void snap() {
    clear
    string packageManager = "snap";
    string check = checkpm(packageManager);
    if (check == "1") {
        std::cout << "You dont have that package mananger installed";
        welcome();
    }
    std::cout << "You are now managing snap" << std::endl;
    std::cout << "Avalible commands:'install','remove','exit' " << std::endl;
    //Idk whose gonna use either this but is here 
    std::string input;
    std::cin >> input;
    if (input == "install" || input == "Install") {
            //this is defenetly not from OpenCW
            //developers never copy :)
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("sudo snap install " + input).c_str());
            snap();
    }
    else if (input == "remove" || input == "Remove") {
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("sudo snap remove " + input).c_str());
            snap();
    }

    else if (input == "exit" || input == "Exit") {
        clear
    }

    else{
        std::cout << "Invalid input! Retrying" << std::endl;
        system("read -p 'Press Enter to continue...'");
        snap();
    }

}

void arch() {
    std::string input;
    std::cin >> input;
    if (input == "update" || input == "Update") {
        clear
        system("sudo pacman -Syy");
        system("sudo pacman -Syu");
        welcome();
        
        arch();
    }
    else if (input == "install" || input == "Install") {
            //this is defenetly not from OpenCW
            //developers never copy :)
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("sudo pacman -S " + input).c_str());
            welcome();
            
            arch();
    }
    else if (input == "remove" || input == "Remove") {
            clear
            std::string input;
            std::cout << "Enter packages name(s): ";
            std::cin >> input;
            system(("sudo pacman -R " + input).c_str());
            welcome();
            
            arch();
    }
    else if (input == "aur" || input == "AUR") {
        aur();
        welcome();
        
        arch();
    }
    else if (input == "pip" || input == "Pip") {
        pip();
        welcome();
        
        arch();
    }
    else if (input == "snap" || input == "Snap") {
        snap();
        welcome();
        
        arch();
    }

    else if (input == "mremove" || input == "Mremove") {
        clear
        std::string input;
        std::cout << "Enter packages name(s): ";
        std::cin >> input;
        system((" sudo pacman -R $(pacman -Qq | grep " + input + ")").c_str());
        welcome();
        
        arch();
    }
    

    else if (input == "exit" || input == "Exit") {
        clear
        std::cout << "Exiting..." << std::endl;
        system("exit");

    }
    else if (input == "flatpak" || input == "Flatpak") {
        flatpak();
        welcome();
        
        arch();
    }
    

    else{
        std::cout << "Invalid input! Retrying" << std::endl;
        system("read -p 'Press Enter to continue...'");
        welcome();
        
        arch();
    }
}

int main() {
    clear
    welcome();
    arch();
}

